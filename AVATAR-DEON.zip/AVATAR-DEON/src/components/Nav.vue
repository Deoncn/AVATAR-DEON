<script setup>

defineProps({
  msg: {
    type: String,
    required: false
  }
})

</script>

<template>

  <n-flex justify="center">
    <n-button strong ghost tag="a" href="/">
      主页
    </n-button>
    <n-button strong ghost tag="a" href="/about">
      关于
    </n-button>
    <n-button strong ghost tag="a" href="/search">
      搜索模块
    </n-button>
    <n-button strong ghost tag="a" href="/login">
      登录
    </n-button>
    <n-button strong ghost tag="a" href="/dashboard">
      管理面板
    </n-button>
  </n-flex>


</template>


