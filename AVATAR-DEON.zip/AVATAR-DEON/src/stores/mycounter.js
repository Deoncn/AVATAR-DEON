import {defineStore} from "pinia";
import request from "@/utils/request.js";
import {ref} from "vue";

export const useCounterStore = defineStore({
    id: 'counter',
    state: () => ({
        count: 0,
        page:1,
        size:20000,
        main_size:20,
        length,
        total:0,
        DATALIST:[],
    }),

    actions: {
        increaseCount() {
            this.count++
        },
        decreaseCount() {
            this.count--
        },

        initialize() {

            request({
                method: 'GET',
                url: `sms/avatarController/getAllAvatar/${this.page}/${this.size}`,
            }).then(res => {
                // 打印初始化数据 👉 console.log(res)
                console.log(res);
                this.length = res.data.data["pages"];
                this.total = res.data.data.total;
                this.DATALIST = res.data.data["records"];
            }).catch(error => {
                console.log(error);
            })

        },

        maininitialize() {

            request({
                method: 'GET',
                url: `sms/avatarController/getAllAvatar/${this.page}/${this.main_size}`,
            }).then(res => {
                // 打印初始化数据 👉 console.log(res)
                console.log(res);
                this.length = res.data.data["pages"];
                this.total = res.data.data.total;
                this.DATALIST = res.data.data["records"];
            }).catch(error => {
                console.log(error);
            })

        }

    },

    getters: {
        oddOrEven: (state) => {
            if (state.count % 2 === 0) return 'even'
            return 'odd'
        }
    }


})