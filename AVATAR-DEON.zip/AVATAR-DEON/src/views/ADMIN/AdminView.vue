<script setup>

import request from '../../utils/request.js'
import {onMounted, ref} from "vue";
//DELETE
import {useDialog, useMessage} from "naive-ui";
import {useCounterStore} from "@/stores/mycounter.js";
const storeCounter = useCounterStore()



//列表

let mult = ref(false)
function MULTIPLE_DELETE(){
  mult.value = true
  columns.value = createColumns();
}
function SINGLE_DELETE(){
  mult.value = false
  columns.value = createColumns();

}


const createColumns = () =>
 [
    {

      multiple: mult.value,
      type: "selection",
    },
    {
      title: "Id",
      key: "id"
    },
    {
      title: "图像地址",
      key: "address"
    },
    {
      title: "描述/关键词",
      key: "des"
    },
    {
      title: "标题",
      key: "title"
    },
    {
      title: "图像后缀",
      key: "fileextension"
    }
  ];

const checkedRowKeysRef = ref([]);

function handleCheck(rowKeys,row) {
  EDITAVATAROBJ.value = row[0]
  checkedRowKeysRef.value = rowKeys;
  DELETELIST.value = rowKeys;
  console.log(DELETELIST.value)
}

const rowKey = (row) => (row.id);
const columns = ref(createColumns());
const pagination = ref({pageSize: 10});


// GET
const page = ref(1);
const size = ref(20000);

const length = ref();
const total = ref();

const DATALIST = ref([]);

function initialize() {

  request({
    method: 'GET',
    url: `sms/avatarController/getAllAvatar/${page.value}/${size.value}`,
  }).then(res => {
    // 打印初始化数据 👉 console.log(res)
    // console.log(res);
    length.value = res.data.data["pages"];
    total.value = res.data.data.total;
    DATALIST.value = res.data.data["records"];
  }).catch(error => {
    console.log(error);

  })
}

const message = useMessage();
const dialog = useDialog();

// DELETE
function handleConfirm() {
  dialog.warning({
    title: "删除",
    content: "确定删除？",
    positiveText: "确定",
    negativeText: "不删除",
    onPositiveClick() {
      if (DELETELIST.value.length !== 0) {
        message.success("删除成功");
        CONFIRM_DELETE(DELETELIST.value)
      } else {
        message.success("删除失败")
      }
    },
    onNegativeClick() {
      // message.error("不确定");
    }
  });
}

let DELETELIST = ref([])

function CONFIRM_DELETE(delete_data) {
  request({
    method: 'DELETE',
    url: 'sms/avatarController/deleteAvatar',
    data: delete_data,
  }).then(res => {
    console.log(res)
    // 删除后清空数组
    DELETELIST.value.length = 0
    storeCounter.initialize();
  }).catch(res => {
    console.log(res)
  })
}


//ADD/SAVE

let showModal = ref(false);
let EDITModal = ref(false);

const EDITAVATAROBJ = ref(
    {
      address: 'https://deoncn.github.io/favicon.ico',
      title: "123",
      des: "123",
      fileextension: "123",
    });

const ADD_OBJ = ref(
    {
      address: 'https://deon.oss-cn-chengdu.aliyuncs.com/avatars/XXXXX.jpg',
      title: "1234",
      des: "123",
      fileextension: "123",
    });

function ADD_OR_SAVE() {
 if( EDITModal.value === true ){
   request({
     method: 'POST',
     url: 'sms/avatarController/saveOrUpdateAvatar',
     data: EDITAVATAROBJ.value
   }).then(res => {
     // console.log(res)
     storeCounter.initialize();
     EDITModal.value = false
     console.log("保存成功")
   }).catch(error => {
     console.log(error)
   })
 }
 else {
   request({
     method: 'POST',
     url: 'sms/avatarController/saveOrUpdateAvatar',
     data: ADD_OBJ.value
   }).then(res => {
     // console.log(res)
     storeCounter.initialize();
     showModal.value = false
     console.log("添加成功")
   }).catch(error => {
     console.log(error)
   })
 }


    // Object.assign(this.desserts[this.editedIndex], this.editedItem)
  }

function IFSINGLEMODE (){
  if( mult.value === false && DELETELIST.value.length !== 0 ){
    //  打开编辑框
    EDITModal.value = true
    //  编辑内容

    //  发送修改信息 （成功/失败）

    // EDITModal.value = false
    // 刷新列表
  }else {
    alert( "未转换为单选或未选择条目无法修改！")
  }
}


// 生命周期
onMounted(() => {
  storeCounter.initialize();
});

</script>

<template>


  <n-space>
    <n-flex>

      <n-modal v-model:show="showModal" preset="dialog" title="Dialog">
        <template #header>
          <div>添加新头像</div>
        </template>

        <n-avatar
            :size="64"
            :src="ADD_OBJ.address"
        />
        <n-form-item label="头像" path="user.name">
          <n-input v-model:value="ADD_OBJ.address" placeholder="头像"/>
        </n-form-item>
        <n-form-item label="描述/关键词" path="user.age">
          <n-input v-model:value="ADD_OBJ.des" placeholder="描述/关键词"/>
        </n-form-item>
        <n-form-item label="标题" path="phone">
          <n-input v-model:value="ADD_OBJ.title" placeholder="标题"/>
        </n-form-item>
        <n-form-item label="图像后缀" path="phone">
          <n-input v-model:value="ADD_OBJ.fileextension" placeholder="图像后缀"/>
        </n-form-item>

        <template #action>
          <n-button @click="ADD_OR_SAVE"> 确认添加</n-button>
          <n-button @click="showModal = false"> 取消</n-button>
        </template>
      </n-modal>

      <n-modal v-model:show="EDITModal" preset="dialog" title="Dialog">
        <template #header>
          <div>修改头像</div>
        </template>

        <n-avatar
            :size="64"
            :src="EDITAVATAROBJ.address"
        />
        <n-form-item label="头像" path="user.name">
          <n-input v-model:value="EDITAVATAROBJ.address" placeholder="头像"/>
        </n-form-item>
        <n-form-item label="描述/关键词" path="user.age">
          <n-input v-model:value="EDITAVATAROBJ.des" placeholder="描述/关键词"/>
        </n-form-item>
        <n-form-item label="标题" path="phone">
          <n-input v-model:value="EDITAVATAROBJ.title" placeholder="标题"/>
        </n-form-item>
        <n-form-item label="图像后缀" path="phone">
          <n-input v-model:value="EDITAVATAROBJ.fileextension" placeholder="图像后缀"/>
        </n-form-item>

        <template #action>
          <n-button @click="ADD_OR_SAVE"> 保存</n-button>
          <n-button @click="EDITModal = false"> 取消</n-button>
        </template>
      </n-modal>



      <n-button @click="showModal = true"> 添加</n-button> <hr>
      <n-button @click="IFSINGLEMODE"> 修改</n-button>



      <n-button @click="MULTIPLE_DELETE">多选模式</n-button>
      <n-button @click="SINGLE_DELETE">单选模式</n-button>
      <n-button @click="handleConfirm"> 删除</n-button>

    </n-flex>


    <n-data-table striped
                  size="large"
                  :columns="columns"
                  :data="storeCounter.DATALIST"
                  :pagination="pagination"
                  :row-key="rowKey"
                  @update:checked-row-keys="handleCheck"
    />

    <n-card> 共 {{ storeCounter.length }} 页, 总共 {{ storeCounter.total }} 个</n-card>

  </n-space>


</template>
