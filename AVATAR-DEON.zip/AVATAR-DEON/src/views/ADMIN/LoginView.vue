<template>

  <n-form
      ref="formRef"
      inline
      :label-width="80"
      :model="formValue"
      :rules="rules"
      :size="size"
  >
    <n-form-item label="账号" path="user.name">
      <n-input v-model:value="formValue.user.name" placeholder="输入姓名" />
    </n-form-item>
    <n-form-item label="密码" path="user.age">
      <n-input v-model:value="formValue.user.age" placeholder="输入年龄" />
    </n-form-item>

    <n-form-item>
      <n-button attr-type="button" @click="handleValidateClick">
        登录
      </n-button>
    </n-form-item>
  </n-form>

  <pre>{{ JSON.stringify(formValue, null, 2) }}
</pre>
</template>

<script>
import { defineComponent, ref } from "vue";
import { useMessage } from "naive-ui";

export default defineComponent({
  setup() {
    const formRef = ref(null);
    const message = useMessage();
    return {
      formRef,
      size: ref("medium"),
      formValue: ref({
        user: {
          name: "",
          age: ""
        }
      }),
      rules: {
        user: {
          name: {
            required: true,
            message: "请输入账号",
            trigger: "blur"
          },
          age: {
            required: true,
            message: "请输入密码",
            trigger: ["input", "blur"]
          }
        },
      },
      handleValidateClick(e) {
        e.preventDefault();
        formRef.value?.validate((errors) => {
          if (!errors) {
            message.success("Valid");

          } else {
            console.log(errors);
            message.error("Invalid");
          }
        });
      }
    };
  }
});

</script>
