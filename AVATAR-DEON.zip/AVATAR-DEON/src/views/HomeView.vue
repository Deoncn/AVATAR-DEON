<script setup>

import { darkTheme } from "naive-ui";
import {onMounted, ref} from "vue";
import {useCounterStore} from "@/stores/mycounter.js";
const theme = ref(null);
const storeCounter = useCounterStore()

function downloadImage(url, filename) {
  // 创建一个图片元素
  const img = new Image();

  // 设置图片的 src 属性为指定的 URL
  img.src = url;

  // 创建一个链接
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;

  // 当图片加载完成后，将图片添加到链接上
  img.onload = function() {
    link.appendChild(img);

    // 将链接添加到页面上
    document.body.appendChild(link);

    // 模拟点击链接来触发下载
    link.click();

    // 清理工作，删除链接
    document.body.removeChild(link);
  };
}

function SHOWPAGE(){
  console.log()
  storeCounter.maininitialize()
}


onMounted(() => {
  storeCounter.maininitialize();
});


</script>

<template>

  <main>

    <div >
      <n-flex>
      <n-space justify="start">


        <n-card v-for="item in storeCounter.DATALIST" :key="item.id" :title="item.title" :theme="darkTheme">
          <template #cover>
            <img draggable="false"  id="qr-code" :src="item.address" alt="">
          </template>
          描述：{{ item.des }}
          <template #action>
            <n-button @click="downloadImage(item.address,item.title + '.' + item.tex )" secondary type="info">下载</n-button>
          </template>

        </n-card>


      </n-space>
      </n-flex>


    </div>



    <n-pagination @click="SHOWPAGE" size="large" v-model:page="storeCounter.page" :page-count="storeCounter.length"/>
  </main>
</template>

<style scoped>
.n-card {
  max-width: 256px;
}

img {
  min-width: 256px;
}

</style>