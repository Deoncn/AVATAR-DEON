<script setup>
import {ref} from 'vue';
import {RouterView} from 'vue-router';
import Nav from './components/Nav.vue';


const theme = ref(null);

</script>


<template>


  <header>
    <Nav></Nav>
  </header>
  <n-modal-provider>
  <n-dialog-provider>
    <n-message-provider>
      <RouterView/>
    </n-message-provider>
  </n-dialog-provider>
  </n-modal-provider>
</template>
