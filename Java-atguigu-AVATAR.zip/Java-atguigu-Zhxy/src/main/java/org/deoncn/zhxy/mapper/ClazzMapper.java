package org.deoncn.zhxy.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.deoncn.zhxy.pojo.Clazz;
import org.springframework.stereotype.Repository;

@Repository
public interface ClazzMapper extends BaseMapper<Clazz> {
}
