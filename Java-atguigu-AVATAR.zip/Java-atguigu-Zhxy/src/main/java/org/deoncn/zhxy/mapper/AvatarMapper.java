package org.deoncn.zhxy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.deoncn.zhxy.pojo.Avatar;
import org.springframework.stereotype.Repository;

@Repository
public interface AvatarMapper extends BaseMapper<Avatar> {

}
