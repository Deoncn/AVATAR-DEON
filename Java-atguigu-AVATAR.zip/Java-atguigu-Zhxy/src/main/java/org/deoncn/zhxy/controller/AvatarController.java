package org.deoncn.zhxy.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.deoncn.zhxy.pojo.Avatar;
import org.deoncn.zhxy.service.AvatarService;
import org.deoncn.zhxy.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Api(tags = "头像接口")
@RestController
@RequestMapping("/sms/avatarController")
public class AvatarController {


    @Autowired
    AvatarService avatarService;

    @ApiOperation("分页带条件查询图片信息")
    @GetMapping("/getAllAvatar/{pageNo}/{pageSize}")
    public Result getAllAdmin(@ApiParam("页码数") @PathVariable("pageNo") Integer pageNo, @ApiParam("页大小") @PathVariable("pageSize") Integer pageSize, @ApiParam("管理员名字") String avatartitle) {

        // 分页 待条件查询
        Page<Avatar> pageParam = new Page<Avatar>(pageNo, pageSize);
        // 通过服务层进行查询
        IPage<Avatar> iPages = avatarService.getGradeByOpr(pageParam, avatartitle);


        // 封装Rusult 对象并返回
        return Result.ok(iPages);
    }


    @ApiOperation("修改新增管理员信息")
    @PostMapping("/saveOrUpdateAvatar")
    public Result saveOrUpdateAdmin(@ApiParam("JSON的Avatar对象") @RequestBody Avatar avatar) {

        avatarService.saveOrUpdate(avatar);
        return Result.ok();
    }


    @ApiOperation("删")
    @DeleteMapping("/deleteAvatar")
    public Result deleteAdmin(@ApiParam("JSON的要删除的Avatar对象") @RequestBody List<Integer> ids) {
        avatarService.removeByIds(ids);
        return Result.ok();
    }
}
