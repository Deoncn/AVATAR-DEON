package org.deoncn.zhxy.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.deoncn.zhxy.mapper.AvatarMapper;
import org.deoncn.zhxy.pojo.Avatar;
import org.deoncn.zhxy.service.AvatarService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;


/**
 * ClassName:AvatarServiceImpl
 * Package: IntelliJ IDEA
 * Description:
 *
 * @ Author: Deoncn
 * @ Create: 2024/5/10 - 上午 2:28
 * @ Version: v1.0
 */
@Service("avatarServiceImpl")
@Transactional
public class AvatarServiceImpl extends ServiceImpl<AvatarMapper, Avatar> implements AvatarService {


    @Override
    public IPage<Avatar> getGradeByOpr(Page<Avatar> pageParam, String avatartitle) {
        QueryWrapper<Avatar> queryWrapper = new QueryWrapper();
        if (!StringUtils.isEmpty(avatartitle)) {
            queryWrapper.like("title",avatartitle);
        }
        queryWrapper.orderByDesc("id");

        IPage<Avatar> PAGE = baseMapper.selectPage(pageParam, queryWrapper);

        return PAGE;
    }


}
