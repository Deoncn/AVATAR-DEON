package org.deoncn.zhxy.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import org.deoncn.zhxy.pojo.Avatar;

/**
 * ClassName:AvatarService
 * Package: IntelliJ IDEA
 * Description:
 *
 * @ Author: Deoncn
 * @ Create: 2024/5/10 - 上午 2:26
 * @ Version: v1.0
 */
public interface AvatarService extends IService<Avatar> {


    IPage<Avatar> getGradeByOpr(Page<Avatar> pageParam, String avatartitle);
}
