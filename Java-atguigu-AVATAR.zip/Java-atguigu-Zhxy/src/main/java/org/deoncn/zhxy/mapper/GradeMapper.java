package org.deoncn.zhxy.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.deoncn.zhxy.pojo.Grade;
import org.springframework.stereotype.Repository;

@Repository
public interface GradeMapper extends BaseMapper<Grade> {
}
